﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Companion
{
    public partial class MainPage : TabbedPage
    {


        public MainPage()
        {
            InitializeComponent();

        }


    }
}
